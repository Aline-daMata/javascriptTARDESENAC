const turnOn = document.getElementById('turnOn');
const turnOff = document.getElementById('turnOff');
const lamp = document.getElementById('lamp');

function isLampBroken() {
    // Verifica se o caminho da imagem contém 'bulboff' e 'quebrada' ou o nome da imagem quebrada
    return lamp.src.indexOf('bulboff') > -1 && lamp.src.includes('quebrada'); 
}

function lampOn() {
    // Só liga se a lâmpada NÃO estiver quebrada
    if (!lamp.src.includes('pic_bulboff.gif') && !lamp.src.includes('bulboff') || !isLampBroken()) { // Simplificando: verifique se o src não é o da quebrada
    }
}

function lampOn() {
    if (!isLampBroken()) {
        lamp.src = 'https://www.w3schools.com/js/pic_bulbon.gif';
    }
}

function lampOff() {
    if (!isLampBroken()) {
        lamp.src = 'https://www.w3schools.com/js/pic_bulboff.gif';
    }
}


function breakLamp() {
 
    lamp.src = 'https://www.w3schools.com/js/pic_bulboff.gif'; .
  
    lamp.src = 'https://www.w3schools.com/js/pic_bulboff.gif'; 
}


function isLampBroken() {
    return lamp.src.indexOf('bulbbroken') > -1; 
}

turnOn.addEventListener('click', lampOn);
turnOff.addEventListener('click', lampOff);

lamp.addEventListener('mouseover', () => {
    if (!isLampBroken()) lampOn();
});
lamp.addEventListener('mouseleave', () => {
    if (!isLampBroken()) lampOff();
});

// Evento de duplo clique para quebrar a lâmpada
lamp.addEventListener('dblclick', () => {
    lamp.src = 'https://www.w3schools.com/js/pic_bulboff.gif'; // Altere para a imagem da lâmpada quebrada
    // Dica: Se quiser usar uma imagem de lâmpada quebrada da W3Schools ou outra hospedada, basta colocar o link direto dela no src.
});